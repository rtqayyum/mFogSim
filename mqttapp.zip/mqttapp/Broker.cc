/*
 * Broker.cc
 *
 *  Created on: Apr 9, 2018
 *      Author: compute1
 */

#ifndef BROKER
#define BROKER

#include "inet/applications/base/ApplicationBase.h"
#include "inet/transportlayer/contract/udp/UDPSocket.h"
namespace inet {
#include "inet/applications/base/ApplicationBase.h"
class Broker {

private:
    const char* brokerID = nullptr;
    L3Address brokerIP;
    int brokerPort;
    int MIPS;
    double busyTime=0.0;
    double fogPrice=0.0;
    double fogAvailability=0.0;
    double fogComCost=0.0;
    int fogLocationID=0;

public:
    Broker() {
        // TODO Auto-generated constructor stub

    }
    Broker(const char* brokerID,
            L3Address brokerIP,
            int brokerPort,
            int MIPS) {
        this->brokerID=brokerID;
        this->brokerIP=brokerIP;
        this->brokerPort=brokerPort;
        this->MIPS=MIPS;
    }
    Broker(const char* brokerID,
                L3Address brokerIP,
                int brokerPort,
                int MIPS,
                double fogPrice,
                double fogAvailability,
                double fogComCost) {
            this->brokerID=brokerID;
            this->brokerIP=brokerIP;
            this->brokerPort=brokerPort;
            this->MIPS=MIPS;
            this->fogPrice=fogPrice;
            this->fogAvailability=fogAvailability;
            this->fogComCost=fogComCost;
        }
    ~Broker() {
        // TODO Auto-generated destructor stub
    }

    const char* getBrokerId() const {
        return brokerID;
    }

    void setBrokerId(const char* brokerId = nullptr) {
        brokerID = brokerId;
    }

    const L3Address& getBrokerIp() const {
        return brokerIP;
    }

    void setBrokerIp(const L3Address& brokerIp) {
        brokerIP = brokerIp;
    }

    int getBrokerPort() const {
        return brokerPort;
    }

    void setBrokerPort(int brokerPort) {
        this->brokerPort = brokerPort;
    }

    int getMips() const {
        return MIPS;
    }

    void setMips(int mips) {
        MIPS = mips;
    }

    double getBusyTime() const {
        return busyTime;
    }

    void setBusyTime(double busyTime = 0.0) {
        this->busyTime = busyTime;
    }

    double getFogAvailability() const {
        return fogAvailability;
    }

    void setFogAvailability(double fogAvailability = 0.0) {
        this->fogAvailability = fogAvailability;
    }

    double getFogComCost() const {
        return fogComCost;
    }

    void setFogComCost(double fogComCost = 0.0) {
        this->fogComCost = fogComCost;
    }

    double getFogPrice() const {
        return fogPrice;
    }

    void setFogPrice(double fogPrice = 0.0) {
        this->fogPrice = fogPrice;
    }

    int getFogLocationId() const {
        return fogLocationID;
    }

    void setFogLocationId(int fogLocationId = 0) {
        fogLocationID = fogLocationId;
    }
};

}
#endif



